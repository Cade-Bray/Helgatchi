G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.3*
G04 #@! TF.CreationDate,2026-01-22T11:37:01-07:00*
G04 #@! TF.ProjectId,Helgatchi front PCB,48656c67-6174-4636-9869-2066726f6e74,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3) date 2026-01-22 11:37:01*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.700000*%
%ADD11RoundRect,0.250000X0.600000X-0.600000X0.600000X0.600000X-0.600000X0.600000X-0.600000X-0.600000X0*%
%ADD12C,4.400000*%
%ADD13RoundRect,0.250000X0.600000X0.600000X-0.600000X0.600000X-0.600000X-0.600000X0.600000X-0.600000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X144780000Y-104145000D03*
D11*
X147320000Y-104145000D03*
D10*
X149860000Y-104145000D03*
X152400000Y-104145000D03*
X154940000Y-104145000D03*
X157480000Y-104145000D03*
X160020000Y-104145000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H3*
X168910000Y-135890000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X168910000Y-82550000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X135890000Y-135890000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,M1*
X135890000Y-120962500D03*
D13*
X135890000Y-123502500D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H1*
X135890000Y-82550000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,BZ1*
X135890000Y-128900000D03*
D13*
X135890000Y-131440000D03*
G04 #@! TD*
M02*
