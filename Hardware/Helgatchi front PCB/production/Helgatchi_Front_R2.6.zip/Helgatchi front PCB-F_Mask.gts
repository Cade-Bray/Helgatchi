G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.3*
G04 #@! TF.CreationDate,2026-02-10T18:35:38-07:00*
G04 #@! TF.ProjectId,Helgatchi front PCB,48656c67-6174-4636-9869-2066726f6e74,R2.6*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3) date 2026-02-10 18:35:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,5.000000*%
%ADD11C,3.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,Untitled*
X148100000Y-88650000D03*
X179900000Y-88650000D03*
X148100000Y-64350000D03*
X179900000Y-64350000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,H1*
X183000000Y-132500000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X145000000Y-132500000D03*
G04 #@! TD*
M02*
